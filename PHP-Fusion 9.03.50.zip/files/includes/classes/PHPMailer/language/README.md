Other languages you can find here: https://github.com/PHPMailer/PHPMailer/tree/master/language
