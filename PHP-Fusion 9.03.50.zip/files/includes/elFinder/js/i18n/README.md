Other languages you can find here: https://github.com/Studio-42/elFinder/tree/master/js/i18n
